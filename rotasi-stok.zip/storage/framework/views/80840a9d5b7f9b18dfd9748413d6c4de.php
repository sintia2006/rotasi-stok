<?php $__env->startSection('title', 'Barang Keluar - ROTASI STOK'); ?>
<?php $__env->startSection('heading', 'Barang Keluar'); ?>
<?php $__env->startSection('subheading', 'Catat pengurangan stok barang dari persediaan toko.'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .panel {
            background: white;
            padding: 25px;
            border-radius: 14px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.04);
        }

        .panel h2 {
            font-size: 19px;
            color: #172554;
            margin-bottom: 20px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            color: #475569;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #dbe2ea;
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            background: white;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #2563eb;
        }

        .full {
            grid-column: 1 / -1;
        }

        .btn-submit {
            background: #dc2626;
            color: white;
            border: none;
            padding: 13px 22px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-submit:hover {
            background: #b91c1c;
        }

        .alert {
            padding: 13px 16px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .success {
            background: #dcfce7;
            color: #166534;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 750px;
        }

        th {
            background: #fff1f2;
            color: #9f1239;
            padding: 14px;
            text-align: left;
            font-size: 13px;
        }

        td {
            padding: 14px;
            border-bottom: 1px solid #e5e7eb;
            font-size: 13px;
        }

        .badge-keluar {
            background: #fee2e2;
            color: #b91c1c;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .empty {
            text-align: center;
            color: #94a3b8;
            padding: 25px;
        }

        .pagination {
            margin-top: 20px;
        }

        @media(max-width: 700px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <div class="alert success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert error">
            <strong>Terjadi kesalahan:</strong>
            <ul style="margin: 8px 0 0 20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="panel">
        <h2>➖ Form Tambah Barang Keluar</h2>

        <form action="<?php echo e(route('barang-keluar.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-grid">

                <div class="form-group full">
                    <label>Pilih Barang</label>

                    <select name="barang_id" required>
                        <option value="">-- Pilih Barang --</option>

                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($barang->id); ?>"
                                <?php echo e(old('barang_id') == $barang->id ? 'selected' : ''); ?>>
                                <?php echo e($barang->kode_barang); ?> - <?php echo e($barang->nama_barang); ?>

                                (Stok: <?php echo e($barang->stok); ?> <?php echo e($barang->satuan); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Jumlah Barang Keluar</label>

                    <input type="number"
                           name="jumlah"
                           min="1"
                           value="<?php echo e(old('jumlah')); ?>"
                           placeholder="Masukkan jumlah barang"
                           required>
                </div>

                <div class="form-group">
                    <label>Harga per Satuan (Rp)</label>

                    <input type="number"
                           name="harga"
                           min="0"
                           step="0.01"
                           value="<?php echo e(old('harga')); ?>"
                           placeholder="Contoh: 15000">
                </div>

                <div class="form-group">
                    <label>Tanggal Keluar</label>

                    <input type="date"
                           name="tanggal"
                           value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>"
                           required>
                </div>

                <div class="form-group">
                    <label>Keterangan</label>

                    <input type="text"
                           name="keterangan"
                           value="<?php echo e(old('keterangan')); ?>"
                           placeholder="Contoh: Penjualan kepada pelanggan">
                </div>

                <div class="form-group full">
                    <button type="submit" class="btn-submit">
                        💾 Simpan Barang Keluar
                    </button>
                </div>

            </div>
        </form>
    </div>


    <div class="panel">
        <h2>📋 Riwayat Barang Keluar</h2>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($transaksis->firstItem() + $index); ?></td>

                            <td>
                                <?php echo e($transaksi->tanggal->format('d-m-Y')); ?>

                            </td>

                            <td>
                                <?php echo e($transaksi->barang->kode_barang ?? '-'); ?>

                            </td>

                            <td>
                                <?php echo e($transaksi->barang->nama_barang ?? 'Barang dihapus'); ?>

                            </td>

                            <td>
                                <?php echo e(number_format($transaksi->jumlah)); ?>

                                <?php echo e($transaksi->barang->satuan ?? ''); ?>

                            </td>

                            <td>
                                Rp <?php echo e(number_format($transaksi->harga, 0, ',', '.')); ?>

                            </td>

                            <td><?php echo e($transaksi->keterangan ?? '-'); ?></td>

                            <td>
                                <span class="badge-keluar">Barang Keluar</span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="empty">
                                Belum ada transaksi barang keluar.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="pagination">
            <?php echo e($transaksis->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rotasi-stok\resources\views/transaksi/keluar.blade.php ENDPATH**/ ?>