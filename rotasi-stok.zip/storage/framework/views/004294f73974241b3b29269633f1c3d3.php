<?php $__env->startSection('title', 'Tambah Pengguna | Rotasi Stok Retail'); ?>
<?php $__env->startSection('heading', 'Tambah Pengguna'); ?>
<?php $__env->startSection('subheading', 'Tambahkan akun pengguna baru ke sistem.'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .form-card {
            max-width: 750px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--app-heading);
            font-size: 14px;
            font-weight: 600;
        }

        .form-group input {
            width: 100%;
            padding: 12px 13px;
            color: var(--app-text);
            background: var(--app-surface);
            border: 1px solid #dce3ec;
            border-radius: 8px;
            outline: none;
        }

        .form-group input:focus {
            border-color: var(--app-primary);
            box-shadow: 0 0 0 3px rgba(36, 120, 220, .1);
        }

        .error {
            margin-top: 6px;
            color: var(--app-danger);
            font-size: 13px;
        }

        .info {
            margin-bottom: 22px;
            padding: 13px;
            color: #3566a0;
            background: #edf5ff;
            border-radius: 8px;
            font-size: 13px;
        }

        .buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }

        .btn-save {
            color: #fff;
            background: var(--app-primary);
        }

        .btn-save:hover {
            background: var(--app-primary-dark);
        }

        .btn-back {
            color: #39465a;
            background: #e9edf3;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel form-card">
        <div class="info">
            Lengkapi seluruh informasi di bawah untuk membuat akun pengguna baru.
        </div>

        <form action="<?php echo e(route('users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input type="text"
                       id="name"
                       name="name"
                       value="<?php echo e(old('name')); ?>"
                       placeholder="Masukkan nama lengkap"
                       required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text"
                       id="username"
                       name="username"
                       value="<?php echo e(old('username')); ?>"
                       placeholder="Masukkan username"
                       required>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email"
                       id="email"
                       name="email"
                       value="<?php echo e(old('email')); ?>"
                       placeholder="Masukkan email"
                       required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password"
                       id="password"
                       name="password"
                       placeholder="Minimal 8 karakter"
                       required
                       autocomplete="new-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password_confirmation">Konfirmasi Password</label>
                <input type="password"
                       id="password_confirmation"
                       name="password_confirmation"
                       placeholder="Ulangi password"
                       required
                       autocomplete="new-password">
            </div>

            <div class="buttons">
                <button type="submit" class="btn btn-save">
                    Simpan Pengguna
                </button>

                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-back">
                    Kembali
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rotasi-stok\resources\views\users\create.blade.php ENDPATH**/ ?>