<?php $__env->startSection('title', 'Profil Admin | Rotasi Stok Retail'); ?>
<?php $__env->startSection('heading', 'Profil Admin'); ?>
<?php $__env->startSection('subheading', 'Kelola informasi akun administrator Rotasi Stok Retail.'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .profile-card {
            max-width: 900px;
        }

        .profile-top {
            display: flex;
            align-items: center;
            gap: 18px;
            padding-bottom: 25px;
            margin-bottom: 25px;
            border-bottom: 1px solid var(--app-border);
        }

        .profile-avatar {
            display: grid;
            place-items: center;
            flex: 0 0 72px;
            width: 72px;
            height: 72px;
            font-size: 32px;
            background: #e5efff;
            border-radius: 50%;
        }

        .profile-top h2 {
            margin-bottom: 5px;
            color: var(--app-heading);
            font-size: 20px;
        }

        .profile-top p {
            color: var(--app-muted);
            font-size: 13px;
        }

        .section-title {
            margin: 25px 0 18px;
            padding-bottom: 12px;
            color: var(--app-heading);
            font-size: 16px;
            border-bottom: 1px solid var(--app-border);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--app-heading);
            font-size: 14px;
            font-weight: 600;
        }

        .form-group input {
            width: 100%;
            padding: 12px 14px;
            color: var(--app-text);
            background: var(--app-surface);
            border: 1px solid #dce3ec;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
        }

        .form-group input:focus {
            border-color: var(--app-primary);
            box-shadow: 0 0 0 3px rgba(36, 120, 220, .1);
        }

        .info {
            margin-bottom: 20px;
            color: var(--app-muted);
            font-size: 13px;
        }

        .success {
            padding: 14px;
            margin-bottom: 20px;
            color: #237746;
            background: #e4f7eb;
            border-radius: 9px;
        }

        .error {
            margin-top: 6px;
            color: var(--app-danger);
            font-size: 13px;
        }

        .error-box {
            padding: 12px 14px;
            margin-bottom: 20px;
            color: #b83232;
            background: #fff0f0;
            border-radius: 9px;
            font-size: 13px;
        }

        .buttons {
            display: flex;
            gap: 12px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 22px;
            border: none;
            border-radius: 9px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }

        .btn-save {
            color: #fff;
            background: var(--app-primary);
        }

        .btn-save:hover {
            background: var(--app-primary-dark);
        }

        .btn-back {
            color: #344054;
            background: #e8edf3;
        }

        @media (max-width: 600px) {
            .profile-top {
                align-items: flex-start;
            }

            .btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel profile-card">
        <div class="profile-top">
            <div class="profile-avatar" aria-hidden="true">👤</div>

            <div>
                <h2><?php echo e($user->name); ?></h2>
                <p>Administrator Rotasi Stok Retail</p>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="error-box">
                Ada data yang belum benar. Silakan periksa kembali.
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <h3 class="section-title">Informasi Akun</h3>

            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input type="text"
                       id="name"
                       name="name"
                       value="<?php echo e(old('name', $user->name)); ?>"
                       required>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text"
                       id="username"
                       name="username"
                       value="<?php echo e(old('username', $user->username)); ?>"
                       required>

                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email"
                       id="email"
                       name="email"
                       value="<?php echo e(old('email', $user->email)); ?>"
                       required>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <h3 class="section-title">Ganti Password</h3>

            <p class="info">
                Kosongkan kedua kolom password jika tidak ingin menggantinya.
            </p>

            <div class="form-group">
                <label for="password">Password Baru</label>
                <input type="password"
                       id="password"
                       name="password"
                       placeholder="Masukkan password baru"
                       autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password_confirmation">Konfirmasi Password Baru</label>
                <input type="password"
                       id="password_confirmation"
                       name="password_confirmation"
                       placeholder="Ulangi password baru"
                       autocomplete="new-password">
            </div>

            <div class="buttons">
                <button type="submit" class="btn btn-save">
                    💾 Simpan Perubahan
                </button>

                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-back">
                    ← Kembali
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rotasi-stok\resources\views\profile\edit.blade.php ENDPATH**/ ?>